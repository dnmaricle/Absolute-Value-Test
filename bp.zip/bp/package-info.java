/**
 * This package provides the business logic
 * functionality for our Circuit.
 *@author David Maricle
 */
package bp;